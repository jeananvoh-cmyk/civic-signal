const e="/assets/fuite-eau-DeqZ68lH.png";export{e as f};
