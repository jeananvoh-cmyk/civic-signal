import{c as y,j as e,B as u,aU as g,b as a}from"./index-CWOINLSw.js";import{D as j,a as k,b as C,c as n}from"./dropdown-menu-Cd_u7Eyx.js";/**
 * @license lucide-react v0.462.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=y("Share2",[["circle",{cx:"18",cy:"5",r:"3",key:"gq8acd"}],["circle",{cx:"6",cy:"12",r:"3",key:"w7nqdw"}],["circle",{cx:"18",cy:"19",r:"3",key:"1xt0gg"}],["line",{x1:"8.59",x2:"15.42",y1:"13.51",y2:"17.49",key:"47mynk"}],["line",{x1:"15.41",x2:"8.59",y1:"6.51",y2:"10.49",key:"1n3mei"}]]),f=({title:o,text:r,url:t,className:i,variant:l="outline",size:p="sm"})=>{const s=t||window.location.href,h=async()=>{if(navigator.share)try{await navigator.share({title:o,text:r,url:s})}catch{}else m()},d=()=>{const x=`${r}

👉 ${s}`,w=`https://wa.me/?text=${encodeURIComponent(x)}`;window.open(w,"_blank","noopener,noreferrer")},m=async()=>{try{await navigator.clipboard.writeText(`${r}
${s}`),a.success("Lien copié dans le presse-papier !")}catch{a.error("Impossible de copier")}};return e.jsxs(j,{children:[e.jsx(k,{asChild:!0,children:e.jsxs(u,{variant:l,size:p,className:i,children:[e.jsx(c,{className:"h-4 w-4 mr-1.5"}),"Partager"]})}),e.jsxs(C,{align:"end",className:"w-48",children:[e.jsxs(n,{onClick:d,className:"cursor-pointer",children:[e.jsx(g,{className:"h-4 w-4 mr-2 text-emerald-500"}),"WhatsApp"]}),e.jsxs(n,{onClick:h,className:"cursor-pointer",children:[e.jsx(c,{className:"h-4 w-4 mr-2"}),navigator.share?"Autres apps":"Copier le lien"]})]})]})};export{f as S};
